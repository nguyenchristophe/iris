<?php
namespace Ves\Brand\Block;

class BrandFilter extends \Magento\Framework\View\Element\Template
{
    protected $connection;
    protected $_resource;
    protected $_storeManager;
    protected $_brandHelper;
    protected $_scopeConfig;

	public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Ves\Brand\Helper\Data $brandHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeInterface,
         array $data = []
    ) {
        $this->_resource = $resource;
        $this->_storeManager = $storeManager;
        $this->_brandHelper = $brandHelper;
        $this->_scopeConfig = $scopeInterface;
        parent::__construct($context, $data);
    }

    protected function getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        }
        return $this->connection;
    }

    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }

    public function getRootStoreId()
    {
        $store = $this->_resource->getTableName('store');
        $query = "SELECT store_id FROM $store WHERE $store.website_id = 0 AND $store.sort_order = 0 AND $store.is_active = 1;";
        $store = $this->getConnection()->fetchRow($query);
        if ($store) {
            return $store["store_id"];
        }
        return 0;
    }

    public function getBrandList()
    {
        $ves_brand = $this->_resource->getTableName('ves_brand');
        $ves_brand_store = $this->_resource->getTableName('ves_brand_store');
        $store_id = $this->getStoreId();
        $store_root_id = $this->getRootStoreId();
        $query = "SELECT * FROM $ves_brand LEFT JOIN $ves_brand_store ON $ves_brand.brand_id = $ves_brand_store.brand_id WHERE $ves_brand_store.store_id IN ($store_id, $store_root_id);";
        $brands = $this->getConnection()->fetchAll($query);
        return $brands;
    }

    public function getCategories() {
        $objectManager = $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $categoryFactory = $objectManager->create('Magento\Catalog\Model\ResourceModel\Category\CollectionFactory');
        $categories = $categoryFactory->create()      
            ->addAttributeToFilter('level', ['eq' => 3])                   
            ->addAttributeToSelect('*')
            ->setStore($this->_storeManager->getStore());

        $results = [];
        $is_action = [];
        $sub_categories_collection = [];
        $sub_categories = [];
        foreach ($categories as $category){
            $data = [
                'category_id' => $category->getId(),
                'name' => $category->getName(),
                'link' => $category->getUrl()
            ];
            if ($category->getData('category_is_action')) {
                foreach($category->getChildrenCategories() as $action) {
                    $is_action[] = [
                        'category_id' => $action->getId(),
                        'name' => $action->getName(),
                        'link' => $action->getUrl()
                    ];
                }
                continue;
            }
            $results[] = $data;
        }

        return [
            'results'   => $results,
            'is_action' => $is_action
        ];
    }

    public function getUrlSearchBrandPage() {
        return $this->_scopeConfig->getValue(
            'vesbrand/general_settings/route',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    /**
     * GET IMAGE URL
     *
     * @return bool|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getImageUrl($img)
    {
        $url = false;
        if ($img) {
            $url = $this->_storeManager->getStore()->getBaseUrl(
                    \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                ) . $img;
        };
        return $url;
    }

    /**
     * GET BRAND PAGE URL
     *
     * @return bool|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getUrlBrand($path)
    {
        $url = $this->_storeManager->getStore()->getBaseUrl();
        $route = $this->_brandHelper->getConfig('general_settings/route');
        $url_prefix = $this->_brandHelper->getConfig('general_settings/url_prefix');
        $urlPrefix = '';
        if ($url_prefix) {
            $urlPrefix = $url_prefix . '/';
        }
        $url_suffix = $this->_brandHelper->getConfig('general_settings/url_suffix');
        return $url . $urlPrefix . $path . $url_suffix;
    }
}
