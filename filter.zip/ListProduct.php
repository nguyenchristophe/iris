<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Agenceo\ListProduct\Block\Product;

use Agenceo\ListProduct\Helpers\Utils;
use Magento\Catalog\Model\Category\Interceptor;
use Magento\Framework\Data\Helper\PostHelper;
use Magento\Catalog\Model\Layer\Resolver;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Framework\Url\Helper\Data;
use Magento\Catalog\Helper\Category;
use Magento\Catalog\Block\Product\Context;

/**
 * Product list
 * @api
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 100.0.2
 */
class ListProduct extends \Magento\Catalog\Block\Product\ListProduct
{
    CONST CATEGORY_IS_ACTION = 'actions_filter';

    protected $category;
    protected $connection;
    protected $_resource;
    protected $_storeManager;
    protected $_brandHelper;
    protected $_scopeConfig;

    /**
     * ListProduct constructor.
     * @param Context $context
     * @param PostHelper $postDataHelper
     * @param Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @param Data $urlHelper
     * @param Category $category
     * @param array $data
     */
    public function __construct(
        Context $context,
        PostHelper $postDataHelper,
        Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository,
        Data $urlHelper,
        Category $category,
        array $data = []
    )
    {
        parent::__construct(
            $context,
            $postDataHelper,
            $layerResolver,
            $categoryRepository,
            $urlHelper,
            $data
        );
        $this->category = $category;
        
        $this->_storeManager = $context->getStoreManager();

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $this->_resource = $resource;

        $brandHelper = $objectManager->get('\Ves\Brand\Helper\Data');
        $this->_brandHelper = $brandHelper;

        $scopeConfig = $objectManager->get('\Magento\Framework\App\Config\ScopeConfigInterface');
        $this->_scopeConfig = $scopeConfig;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getCategories()
    {
        $categories         = [];
        $isRoot             = false;
        $currentCategory    = $this->_coreRegistry->registry('current_category');
        $storeCategories    = $this->category->getStoreCategories();

        if ($currentCategory->getParentCategory()->getLevel() === '1') {
            $isRoot = true;
        }

        foreach ($storeCategories as $category) {
            $categoryObj = $this->categoryRepository->get($category->getId());
            $mainCategories = $categoryObj->getChildrenCategories();

            /** @var Interceptor $mainCategory */
            foreach ($mainCategories as $mainCategory) {
                if (!$mainCategory->getData('category_is_action')) {
                    $categories[$mainCategory->getName()] = [
                        'name'                  => $mainCategory->getName(),
                        'category_subtitle'     => $this->categoryRepository->get($mainCategory->getId())->getData('category_subtitle'),
                        'link'                  => $mainCategory->getUrl(),
                        'back_link'             => $mainCategory->getParentCategory()->getUrl(),
                        'icon'                  => $this->categoryRepository->get($mainCategory->getId())->getData('category_icon'),
                        'current'               => ($currentCategory->getId() === $mainCategory->getId()) || ($currentCategory->getParentCategory()->getId() === $mainCategory->getId()),
                        'category_id'           => $mainCategory->getId(),
                        'currentCategory'       => $currentCategory->getId(),
                        'currentParentCategory' => $currentCategory->getParentCategory()->getId()
                    ];
                    /** @var Interceptor $subCategory */
                    if ($categories[$mainCategory->getName()]['current'] || $isRoot) {
                        foreach ($mainCategory->getChildrenCategories() as $subCategory) {
                            $categories[$mainCategory->getName()]['sub'][] = [
                                'name'              => $subCategory->getName(),
                                'category_subtitle' => $this->categoryRepository->get($subCategory->getId())->getData('category_subtitle'),
                                'link'              => $subCategory->getUrl(),
                                'back_link'         => $mainCategory->getUrl(),
                                'icon'              => $this->categoryRepository->get($subCategory->getId())->getData('category_icon'),
                                'current'           => ($currentCategory->getId()) == $subCategory->getId()
                            ];
                        }
                    }
                } else {
                    foreach ($mainCategory->getChildrenCategories() as $subCategory) {
                        $categories['actions_filter'][] = [
                            'name'              => $subCategory->getName(),
                            'category_subtitle' => $this->categoryRepository->get($subCategory->getId())->getData('category_subtitle'),
                            'link'              => $subCategory->getUrl(),
                            'icon'              => $this->categoryRepository->get($subCategory->getId())->getData('category_icon'),
                            'current'           => ($currentCategory->getId()) == $subCategory->getId()
                        ];
                    }
                }
            }
        }
        $categories['isRoot'] = $isRoot;
        return $categories;
    }

    /**
     * @return bool
     */
    public function getCurrentCategoryIsAction()
    {
        $currentIsAction = false;
        $currentCategory = $this->_coreRegistry->registry('current_category');
        if ($currentCategory->getParentCategory()->getData('category_is_action')) {
            $currentIsAction = true;
        }
        return $currentIsAction;
    }

    protected function getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->_resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        }
        return $this->connection;
    }

    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }

    public function getRootStoreId()
    {
        $store = $this->_resource->getTableName('store');
        $query = "SELECT store_id FROM $store WHERE $store.website_id = 0 AND $store.sort_order = 0 AND $store.is_active = 1;";
        $store = $this->getConnection()->fetchRow($query);
        if ($store) {
            return $store["store_id"];
        }
        return 0;
    }

    public function getBrandList()
    {
        $ves_brand = $this->_resource->getTableName('ves_brand');
        $ves_brand_store = $this->_resource->getTableName('ves_brand_store');
        $store_id = $this->getStoreId();
        $store_root_id = $this->getRootStoreId();
        $query = "SELECT * FROM $ves_brand LEFT JOIN $ves_brand_store ON $ves_brand.brand_id = $ves_brand_store.brand_id WHERE $ves_brand_store.store_id IN ($store_id, $store_root_id);";
        $brands = $this->getConnection()->fetchAll($query);
        return $brands;
    }

    public function getUrlSearchBrandPage() {
        return $this->_scopeConfig->getValue(
            'vesbrand/general_settings/route',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
    
    /**
     * GET IMAGE URL
     *
     * @return bool|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getImageUrl($img)
    {
        $url = false;
        if ($img) {
            $url = $this->_storeManager->getStore()->getBaseUrl(
                    \Magento\Framework\UrlInterface::URL_TYPE_MEDIA
                ) . $img;
        };
        return $url;
    }

    /**
     * GET BRAND PAGE URL
     *
     * @return bool|string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getUrlBrand($path)
    {
        $url = $this->_storeManager->getStore()->getBaseUrl();
        $route = $this->_brandHelper->getConfig('general_settings/route');
        $url_prefix = $this->_brandHelper->getConfig('general_settings/url_prefix');
        $urlPrefix = '';
        if ($url_prefix) {
            $urlPrefix = $url_prefix . '/';
        }
        $url_suffix = $this->_brandHelper->getConfig('general_settings/url_suffix');
        return $url . $urlPrefix . $path . $url_suffix;
    }

}
